/**
 * Web Development Interview Preparation System - Core Logic
 * B.Tech College Project Demonstration
 * Features: Auth (LocalStorage), 25 Viva Questions, 10-min MCQ Test,
 * Scoring Engine, Result Review, Past History, Profile, Admin Dashboard.
 */

// =============================================================================
// 1. DATA REPOSITORY: 25 CORE INTERVIEW & VIVA QUESTIONS
// =============================================================================
const INTERVIEW_QUESTIONS = [
  // --- HTML QUESTIONS ---
  {
    id: 1,
    category: "HTML",
    question: "What is HTML?",
    answer: "HTML stands for HyperText Markup Language. It is the standard markup language used to design and structure the layout of web pages and web applications. HTML elements are represented by tags, which tell the browser how to display content like headings, paragraphs, images, and links."
  },
  {
    id: 2,
    category: "HTML",
    question: "What is the difference between id and class?",
    answer: "An 'id' is a unique identifier within a single HTML document; no two elements should share the same id (used with # in CSS). A 'class' can be assigned to multiple elements to apply identical styles or JavaScript behaviors across several elements (used with . in CSS)."
  },
  {
    id: 3,
    category: "HTML",
    question: "What are semantic tags?",
    answer: "Semantic tags clearly describe their meaning to both the browser and developer. Rather than generic <div> or <span>, semantic tags like <header>, <nav>, <article>, <section>, <aside>, and <footer> explain the purpose of the enclosed content, improving SEO and web accessibility."
  },
  {
    id: 4,
    category: "HTML",
    question: "What are HTML forms?",
    answer: "HTML forms (<form>) are sections of a document containing interactive controls (such as <input>, <textarea>, <select>, and <button>) designed to collect user input and submit it to a web server for processing via HTTP methods like GET or POST."
  },

  // --- CSS QUESTIONS ---
  {
    id: 5,
    category: "CSS",
    question: "What is CSS?",
    answer: "CSS stands for Cascading Style Sheets. It is a stylesheet language used to specify the presentation, layout, visual design, colors, typography, and responsive adaptations of documents written in HTML or XML."
  },
  {
    id: 6,
    category: "CSS",
    question: "What is the difference between margin and padding?",
    answer: "Padding is the space between the element's actual content and its border (inside the box). Margin is the transparent space outside of the element's border, separating it from adjacent HTML elements on the page."
  },
  {
    id: 7,
    category: "CSS",
    question: "What is the CSS Box Model?",
    answer: "The CSS Box Model is a conceptual box that wraps around every HTML element. It consists of four concentric layers from inside to outside: 1. Content (text/media), 2. Padding (inner spacing), 3. Border (frame around padding), and 4. Margin (outer clear area separating other boxes)."
  },
  {
    id: 8,
    category: "CSS",
    question: "What is responsive web design?",
    answer: "Responsive web design (RWD) is an approach where web pages automatically adjust their layout, navigation, typography, and images to look well-proportioned across varied screen sizes and device viewports (smartphones, tablets, laptops, desktops) using CSS Media Queries, flexible grids, and viewport meta tags."
  },

  // --- JAVASCRIPT QUESTIONS ---
  {
    id: 9,
    category: "JavaScript",
    question: "What is JavaScript?",
    answer: "JavaScript is a high-level, interpreted (JIT-compiled), lightweight programming language used to make web pages interactive and dynamic. It runs primarily client-side inside the browser to handle user events, manipulate the DOM, validate forms, and exchange asynchronous data."
  },
  {
    id: 10,
    category: "JavaScript",
    question: "What is the difference between var, let, and const?",
    answer: "1. 'var' is function-scoped and hoisted with an initial value of undefined. 2. 'let' is block-scoped ({ }), can be reassigned, and cannot be redeclared in the same scope. 3. 'const' is also block-scoped but creates an immutable reference; its identifier cannot be reassigned after declaration."
  },
  {
    id: 11,
    category: "JavaScript",
    question: "What is the DOM?",
    answer: "DOM stands for Document Object Model. It is an object-oriented hierarchical tree representation of an HTML document created by the browser. It allows JavaScript programs to dynamically access, add, modify, or delete elements, styles, and attributes in real time."
  },
  {
    id: 12,
    category: "JavaScript",
    question: "What is the difference between == and ===?",
    answer: "The loose equality operator (==) compares values for equality after performing automatic type coercion (e.g., '5' == 5 evaluates to true). The strict equality operator (===) checks both value and data type without any type conversion ('5' === 5 evaluates to false)."
  },
  {
    id: 13,
    category: "JavaScript",
    question: "What is an event in JavaScript?",
    answer: "An event is an action or occurrence that takes place in the browser—such as a user clicking a button ('click'), submitting a form ('submit'), typing in an input ('input' or 'keypress'), or the page finishing loading ('load'). JavaScript registers event listeners to respond to these triggers."
  },

  // --- PHP QUESTIONS ---
  {
    id: 14,
    category: "PHP",
    question: "What is PHP?",
    answer: "PHP stands for Hypertext Preprocessor. It is an open-source, server-side scripting language primarily used for backend web development to create dynamic page content, manage database operations, handle sessions, and process form data securely on the server."
  },
  {
    id: 15,
    category: "PHP",
    question: "What is the difference between GET and POST?",
    answer: "GET appends submitted form data to the URL query string, making it visible in browser history and bookmarks (suitable for search queries with small payload limits). POST transmits data invisibly in the HTTP request body, has no strict length restrictions, and is essential for confidential data like passwords."
  },
  {
    id: 16,
    category: "PHP",
    question: "What is a session in PHP?",
    answer: "A PHP session is a mechanism used to preserve state and user data across multiple web pages for a specific client. It is initialized using session_start(), stores values on the web server in the $_SESSION superglobal array, and identifies the client using a unique cookie (PHPSESSID)."
  },
  {
    id: 17,
    category: "PHP",
    question: "How do you connect PHP with MySQL?",
    answer: "PHP connects to MySQL using either MySQLi (MySQL Improved) or PDO (PHP Data Objects). For example with MySQLi: $conn = new mysqli($servername, $username, $password, $dbname); or using PDO: $pdo = new PDO('mysql:host=localhost;dbname=test', $user, $pass);"
  },

  // --- MYSQL QUESTIONS ---
  {
    id: 18,
    category: "MySQL",
    question: "What is MySQL?",
    answer: "MySQL is an open-source Relational Database Management System (RDBMS) based on Structured Query Language (SQL). It organizes structured data into tables consisting of rows and columns, providing data integrity, ACID compliance, and relational querying."
  },
  {
    id: 19,
    category: "MySQL",
    question: "What is a primary key?",
    answer: "A primary key is a column or set of columns in a relational table that uniquely identifies each individual record (row) in that table. A primary key must contain unique values and cannot contain NULL values. Each table can have only one primary key."
  },
  {
    id: 20,
    category: "MySQL",
    question: "What is a foreign key?",
    answer: "A foreign key is a column or group of columns in one table that points to the primary key in another table. It establishes and enforces a link between the data in two relational tables, ensuring referential integrity across the database."
  },
  {
    id: 21,
    category: "MySQL",
    question: "What is the difference between DELETE and DROP?",
    answer: "DELETE is a DML (Data Manipulation Language) command that deletes specific rows matching a WHERE clause from a table while preserving the table's structure and schema. DROP is a DDL (Data Definition Language) command that removes the entire table structure and all its data permanently from the database."
  },

  // --- WEB DEVELOPMENT & PROJECT VIVA QUESTIONS ---
  {
    id: 22,
    category: "Viva & Concepts",
    question: "What is the difference between frontend and backend?",
    answer: "Frontend is the client-side presentation layer that users see and interact with directly in the browser (HTML, CSS, JavaScript). Backend is the server-side architecture (Node.js, PHP, Python, Java) responsible for business logic, database management, authentication, and API endpoints."
  },
  {
    id: 23,
    category: "Viva & Concepts",
    question: "What is an API?",
    answer: "API stands for Application Programming Interface. It is a set of rules, protocols, and endpoints that allows two distinct software programs or systems to communicate and exchange data, such as a browser frontend requesting JSON data from a backend server."
  },
  {
    id: 24,
    category: "Viva & Concepts",
    question: "What is the main purpose of your Interview Preparation System?",
    answer: "The main purpose of this project is to provide B.Tech students with a clean, centralized, and self-contained web platform to study key web development concepts, test their knowledge via a timed 10-question MCQ mock exam, review mistakes, and monitor placement readiness using pure web standards."
  },
  {
    id: 25,
    category: "Viva & Concepts",
    question: "How does your mock test calculate the final score?",
    answer: "The mock test evaluates the student's submission by comparing each recorded selected option against the verified correct answer in the question bank. Unanswered questions are scored as 0. Score = Total Correct Answers. Percentage = (Score / Total Questions) * 100. Both score and timestamped review are stored in browser LocalStorage."
  }
];

// =============================================================================
// 2. MCQ QUESTION BANK: 10 CURATED QUESTIONS ACROSS ALL TOPICS
// =============================================================================
const MOCK_TEST_QUESTIONS = [
  {
    id: 1,
    topic: "HTML",
    question: "Which HTML5 semantic element represents self-contained content that could be distributed independently?",
    options: [
      "<section>",
      "<article>",
      "<aside>",
      "<div>"
    ],
    correctAnswer: 1, // index 1 -> <article>
    explanation: "<article> specifies independent, self-contained content such as a blog post or news story."
  },
  {
    id: 2,
    topic: "HTML",
    question: "What is the correct HTML element for inserting a line break?",
    options: [
      "<break>",
      "<lb>",
      "<br>",
      "<newline>"
    ],
    correctAnswer: 2, // index 2 -> <br>
    explanation: "<br> produces a line break in text (carriage-return) without creating a new paragraph."
  },
  {
    id: 3,
    topic: "CSS",
    question: "Which CSS property is used to generate space inside an element's border, around its content?",
    options: [
      "margin",
      "spacing",
      "padding",
      "border-spacing"
    ],
    correctAnswer: 2, // index 2 -> padding
    explanation: "Padding adds space inside an element's border, whereas margin creates space outside the border."
  },
  {
    id: 4,
    topic: "CSS",
    question: "In the CSS Box Model, which layer is situated on the very outside?",
    options: [
      "Border",
      "Padding",
      "Content",
      "Margin"
    ],
    correctAnswer: 3, // index 3 -> Margin
    explanation: "From innermost to outermost: Content -> Padding -> Border -> Margin."
  },
  {
    id: 5,
    topic: "JavaScript",
    question: "What is the output of `console.log(typeof null)` in JavaScript?",
    options: [
      "'null'",
      "'undefined'",
      "'object'",
      "'number'"
    ],
    correctAnswer: 2, // index 2 -> 'object'
    explanation: "Due to a historical legacy bug in JavaScript, typeof null returns 'object'."
  },
  {
    id: 6,
    topic: "JavaScript",
    question: "Which method is used to attach a click event listener to a button element in vanilla JavaScript?",
    options: [
      "button.attachClick(handler)",
      "button.addEventListener('click', handler)",
      "button.onClick = handler",
      "button.listen('click', handler)"
    ],
    correctAnswer: 1, // index 1 -> button.addEventListener('click', handler)
    explanation: "addEventListener('click', handler) is the standard modern DOM method to bind event handlers."
  },
  {
    id: 7,
    topic: "PHP",
    question: "All variables in PHP must begin with which specific symbol?",
    options: [
      "&",
      "#",
      "@",
      "$"
    ],
    correctAnswer: 3, // index 3 -> $
    explanation: "In PHP, every variable name must begin with a dollar sign ($), for example: $student_name."
  },
  {
    id: 8,
    topic: "PHP",
    question: "Which PHP superglobal array is used to access form data submitted with method='POST'?",
    options: [
      "$_GET",
      "$_POST",
      "$_REQUEST_DATA",
      "$_BODY"
    ],
    correctAnswer: 1, // index 1 -> $_POST
    explanation: "$_POST is an associative array of variables passed to the current script via the HTTP POST method."
  },
  {
    id: 9,
    topic: "MySQL",
    question: "Which SQL clause is used to filter records based on a specific condition in a SELECT statement?",
    options: [
      "ORDER BY",
      "GROUP BY",
      "WHERE",
      "HAVING ONLY"
    ],
    correctAnswer: 2, // index 2 -> WHERE
    explanation: "The WHERE clause is used to filter rows that satisfy a specified boolean condition."
  },
  {
    id: 10,
    topic: "MySQL",
    question: "Which SQL command deletes all records from a table without deleting the table structure itself?",
    options: [
      "DROP TABLE",
      "DELETE FROM table_name",
      "REMOVE TABLE",
      "ALTER TABLE"
    ],
    correctAnswer: 1, // index 1 -> DELETE FROM table_name
    explanation: "DELETE FROM removes rows while preserving the table schema. DROP permanently eliminates the table structure."
  }
];

// =============================================================================
// 3. STORAGE HELPERS & SEED INITIALIZATION
// =============================================================================
const STORAGE_KEYS = {
  USERS: "wd_users",
  ACTIVE_USER: "wd_active_user",
  HISTORY: "wd_test_history",
  LAST_RESULT: "wd_last_result",
  TEST_STATE: "wd_current_test"
};

/**
 * Initializes browser LocalStorage with default student account and sample history.
 * Called automatically on every page load.
 */
function initStorage() {
  // 1. Initialize or migrate Users List
  const defaultUsers = [
    {
      fullName: "Het Patel",
      email: "hetpatel9181@gmail.com",
      password: "password123",
      semester: "Semester 6",
      rollNo: "21BCE1042",
      targetRole: "Full Stack Web Developer"
    }
  ];

  const existingUsersJson = localStorage.getItem(STORAGE_KEYS.USERS);
  if (!existingUsersJson) {
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(defaultUsers));
  } else {
    // Migrate any existing "Rahul Sharma" to "Het Patel"
    try {
      let users = JSON.parse(existingUsersJson);
      let updated = false;
      users = users.map(u => {
        if (u.fullName === "Rahul Sharma" || u.email === "student@college.edu") {
          updated = true;
          return {
            ...u,
            fullName: "Het Patel",
            email: "hetpatel9181@gmail.com"
          };
        }
        return u;
      });
      if (updated || users.length === 0) {
        localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users.length === 0 ? defaultUsers : users));
      }
    } catch (e) {
      localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(defaultUsers));
    }
  }

  // Also migrate active user in storage if previously saved as Rahul Sharma
  const activeUserJson = localStorage.getItem(STORAGE_KEYS.ACTIVE_USER);
  if (activeUserJson) {
    try {
      let active = JSON.parse(activeUserJson);
      if (active.fullName === "Rahul Sharma" || active.email === "student@college.edu") {
        active.fullName = "Het Patel";
        active.email = "hetpatel9181@gmail.com";
        localStorage.setItem(STORAGE_KEYS.ACTIVE_USER, JSON.stringify(active));
      }
    } catch (e) {}
  }

  // 2. Initialize Sample Test History if empty
  if (!localStorage.getItem(STORAGE_KEYS.HISTORY)) {
    const sampleHistory = [
      {
        id: "TEST-1001",
        date: "2026-10-18 14:30",
        score: 8,
        totalQuestions: 10,
        percentage: 80,
        passed: true,
        durationMinutes: "6 min 15 sec",
        answers: {
          0: 1, 1: 2, 2: 2, 3: 3, 4: 2,
          5: 1, 6: 3, 7: 1, 8: 0, 9: 1
        }
      }
    ];
    localStorage.setItem(STORAGE_KEYS.HISTORY, JSON.stringify(sampleHistory));
  }
}

/**
 * Retrieves the currently logged in student object, or null.
 */
function getActiveUser() {
  const data = localStorage.getItem(STORAGE_KEYS.ACTIVE_USER);
  try {
    return data ? JSON.parse(data) : null;
  } catch (e) {
    return null;
  }
}

/**
 * Requires student authentication for protected pages.
 * If not logged in, auto-logs into demo student Het Patel for seamless viva demonstration.
 */
function requireAuth(autoLoginDemo = true) {
  let user = getActiveUser();
  if (!user && autoLoginDemo) {
    const users = JSON.parse(localStorage.getItem(STORAGE_KEYS.USERS) || "[]");
    if (users.length > 0) {
      user = users[0];
      localStorage.setItem(STORAGE_KEYS.ACTIVE_USER, JSON.stringify(user));
    }
  }
  return user;
}

/**
 * Logs out current user and redirects to login page.
 */
function logoutUser() {
  localStorage.removeItem(STORAGE_KEYS.ACTIVE_USER);
  localStorage.removeItem(STORAGE_KEYS.TEST_STATE);
  window.location.href = "login.html";
}

/**
 * Syncs the top navigation bar with active user information and active page links.
 */
function updateHeaderNav() {
  const user = getActiveUser();
  const userGreetingEl = document.getElementById("nav-user-info");
  const authButtonsEl = document.getElementById("nav-auth-buttons");
  const logoutBtnEl = document.getElementById("nav-logout-btn");

  if (userGreetingEl) {
    if (user) {
      userGreetingEl.innerHTML = `<span class="user-greeting">Hi, <strong>${escapeHtml(user.fullName)}</strong></span>`;
      if (authButtonsEl) authButtonsEl.style.display = "none";
      if (logoutBtnEl) logoutBtnEl.style.display = "inline-flex";
    } else {
      userGreetingEl.innerHTML = "";
      if (authButtonsEl) authButtonsEl.style.display = "flex";
      if (logoutBtnEl) logoutBtnEl.style.display = "none";
    }
  }

  // Highlight active link based on current filename
  const currentPath = window.location.pathname.split("/").pop() || "index.html";
  const navLinks = document.querySelectorAll(".main-nav a, .mobile-nav-menu a");
  navLinks.forEach(link => {
    const href = link.getAttribute("href");
    if (href === currentPath || (currentPath === "" && href === "index.html")) {
      link.classList.add("active");
    } else {
      link.classList.remove("active");
    }
  });

  // Mobile menu toggle button
  const toggleBtn = document.querySelector(".mobile-toggle");
  const mobileMenu = document.querySelector(".mobile-nav-menu");
  if (toggleBtn && mobileMenu) {
    toggleBtn.addEventListener("click", () => {
      mobileMenu.classList.toggle("open");
    });
  }
}

/**
 * Utility function to sanitize HTML input
 */
function escapeHtml(str) {
  if (!str) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

// =============================================================================
// 4. AUTHENTICATION MODULE (login.html & register.html)
// =============================================================================

/**
 * Handles student registration
 */
function setupRegisterForm() {
  const form = document.getElementById("register-form");
  const alertEl = document.getElementById("register-alert");
  if (!form) return;

  form.addEventListener("submit", function (e) {
    e.preventDefault();
    if (alertEl) alertEl.innerHTML = "";

    const fullName = document.getElementById("reg-name").value.trim();
    const email = document.getElementById("reg-email").value.trim().toLowerCase();
    const semester = document.getElementById("reg-semester").value;
    const password = document.getElementById("reg-password").value;
    const confirmPassword = document.getElementById("reg-confirm-password").value;

    // Validation
    if (!fullName || !email || !password) {
      showAlert(alertEl, "Please fill in all mandatory fields.", "error");
      return;
    }

    if (password.length < 6) {
      showAlert(alertEl, "Password must be at least 6 characters long.", "error");
      return;
    }

    if (password !== confirmPassword) {
      showAlert(alertEl, "Passwords do not match. Please verify.", "error");
      return;
    }

    // Check existing email
    const users = JSON.parse(localStorage.getItem(STORAGE_KEYS.USERS) || "[]");
    const existing = users.find(u => u.email === email);
    if (existing) {
      showAlert(alertEl, "An account with this email address already exists. Please login.", "error");
      return;
    }

    // Save new student
    const newUser = {
      fullName,
      email,
      password,
      semester: semester || "Semester 6",
      rollNo: "21BCE" + Math.floor(1000 + Math.random() * 9000),
      targetRole: "Web Developer"
    };

    users.push(newUser);
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));

    // Auto login
    localStorage.setItem(STORAGE_KEYS.ACTIVE_USER, JSON.stringify(newUser));
    showAlert(alertEl, "Registration successful! Redirecting to Dashboard...", "success");

    setTimeout(() => {
      window.location.href = "dashboard.html";
    }, 1200);
  });
}

/**
 * Handles student login
 */
function setupLoginForm() {
  const form = document.getElementById("login-form");
  const alertEl = document.getElementById("login-alert");
  const quickFillBtn = document.getElementById("btn-quick-fill");
  if (!form) return;

  if (quickFillBtn) {
    quickFillBtn.addEventListener("click", () => {
      document.getElementById("login-email").value = "hetpatel9181@gmail.com";
      document.getElementById("login-password").value = "password123";
    });
  }

  form.addEventListener("submit", function (e) {
    e.preventDefault();
    if (alertEl) alertEl.innerHTML = "";

    const email = document.getElementById("login-email").value.trim().toLowerCase();
    const password = document.getElementById("login-password").value;

    if (!email || !password) {
      showAlert(alertEl, "Please enter your email and password.", "error");
      return;
    }

    const users = JSON.parse(localStorage.getItem(STORAGE_KEYS.USERS) || "[]");
    const foundUser = users.find(u => u.email === email && u.password === password);

    if (foundUser) {
      localStorage.setItem(STORAGE_KEYS.ACTIVE_USER, JSON.stringify(foundUser));
      showAlert(alertEl, "Login successful! Welcome back " + foundUser.fullName, "success");
      setTimeout(() => {
        window.location.href = "dashboard.html";
      }, 900);
    } else {
      showAlert(alertEl, "Invalid credentials. Try student@college.edu / password123", "error");
    }
  });
}

function showAlert(container, message, type = "error") {
  if (!container) return;
  const alertClass = type === "success" ? "alert-success" : (type === "info" ? "alert-info" : "alert-error");
  container.innerHTML = `<div class="alert ${alertClass}">${escapeHtml(message)}</div>`;
}

// =============================================================================
// 5. STUDENT DASHBOARD MODULE (dashboard.html)
// =============================================================================
function setupDashboard() {
  const greetingEl = document.getElementById("dash-student-greeting");
  if (!greetingEl) return;

  const user = requireAuth();
  if (!user) return;

  greetingEl.textContent = `Welcome, ${user.fullName}!`;
  
  const rollEl = document.getElementById("dash-roll-no");
  if (rollEl) rollEl.textContent = user.rollNo || "21BCE1042";

  const semEl = document.getElementById("dash-semester");
  if (semEl) semEl.textContent = user.semester || "Semester 6";

  // Compute metrics from test history
  const history = JSON.parse(localStorage.getItem(STORAGE_KEYS.HISTORY) || "[]");
  const testCountEl = document.getElementById("dash-tests-count");
  const latestScoreEl = document.getElementById("dash-latest-score");
  const avgScoreEl = document.getElementById("dash-avg-score");

  if (testCountEl) testCountEl.textContent = history.length;

  if (history.length > 0) {
    const latest = history[history.length - 1];
    if (latestScoreEl) latestScoreEl.textContent = `${latest.score}/${latest.totalQuestions}`;

    const totalSum = history.reduce((acc, curr) => acc + curr.percentage, 0);
    const avg = Math.round(totalSum / history.length);
    if (avgScoreEl) avgScoreEl.textContent = `${avg}%`;
  } else {
    if (latestScoreEl) latestScoreEl.textContent = "None";
    if (avgScoreEl) avgScoreEl.textContent = "0%";
  }

  // Render recent attempts
  const historyListEl = document.getElementById("dash-recent-history");
  if (historyListEl) {
    if (history.length === 0) {
      historyListEl.innerHTML = `<tr><td colspan="5" style="text-align: center; color: #64748b; padding: 2rem;">No test attempts yet. Click 'Start Mock Test' above to take your first test!</td></tr>`;
    } else {
      const recent = [...history].reverse().slice(0, 5);
      historyListEl.innerHTML = recent.map((item, idx) => `
        <tr>
          <td><strong>#${item.id || idx + 1}</strong></td>
          <td>${escapeHtml(item.date)}</td>
          <td><span style="font-weight: 700;">${item.score} / ${item.totalQuestions}</span></td>
          <td>
            <span class="score-badge ${item.passed ? 'passed' : 'failed'}" style="font-size: 0.75rem; padding: 2px 8px;">
              ${item.percentage}% ${item.passed ? 'PASSED' : 'NEEDS PRACTICE'}
            </span>
          </td>
          <td>
            <button class="btn btn-secondary btn-sm" onclick="reviewHistoryTest('${item.id}')">Review</button>
          </td>
        </tr>
      `).join("");
    }
  }
}

function reviewHistoryTest(testId) {
  const history = JSON.parse(localStorage.getItem(STORAGE_KEYS.HISTORY) || "[]");
  const found = history.find(h => h.id === testId);
  if (found) {
    localStorage.setItem(STORAGE_KEYS.LAST_RESULT, JSON.stringify(found));
    window.location.href = "result.html";
  }
}

// =============================================================================
// 6. INTERVIEW QUESTIONS REPOSITORY (questions.html)
// =============================================================================
let activeQuestionCategory = "All";
let questionSearchQuery = "";

function setupQuestionsPage() {
  const container = document.getElementById("questions-list-container");
  if (!container) return;

  renderQuestions();

  // Category filter tabs
  const filterButtons = document.querySelectorAll(".category-btn");
  filterButtons.forEach(btn => {
    btn.addEventListener("click", () => {
      filterButtons.forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      activeQuestionCategory = btn.dataset.category;
      renderQuestions();
    });
  });

  // Search input
  const searchInput = document.getElementById("question-search-input");
  if (searchInput) {
    searchInput.addEventListener("input", (e) => {
      questionSearchQuery = e.target.value.toLowerCase().trim();
      renderQuestions();
    });
  }

  // Expand / Collapse All buttons
  const expandAllBtn = document.getElementById("btn-expand-all");
  const collapseAllBtn = document.getElementById("btn-collapse-all");

  if (expandAllBtn) {
    expandAllBtn.addEventListener("click", () => {
      document.querySelectorAll(".answer-tray").forEach(tray => tray.classList.add("open"));
      document.querySelectorAll(".question-toggle-text").forEach(txt => txt.textContent = "Hide Answer");
    });
  }

  if (collapseAllBtn) {
    collapseAllBtn.addEventListener("click", () => {
      document.querySelectorAll(".answer-tray").forEach(tray => tray.classList.remove("open"));
      document.querySelectorAll(".question-toggle-text").forEach(txt => txt.textContent = "Show Answer");
    });
  }
}

function renderQuestions() {
  const container = document.getElementById("questions-list-container");
  const countEl = document.getElementById("questions-count-badge");
  if (!container) return;

  // Filter based on category and query
  const filtered = INTERVIEW_QUESTIONS.filter(q => {
    const matchesCat = activeQuestionCategory === "All" || q.category === activeQuestionCategory;
    const matchesQuery = !questionSearchQuery || 
      q.question.toLowerCase().includes(questionSearchQuery) || 
      q.answer.toLowerCase().includes(questionSearchQuery) ||
      q.category.toLowerCase().includes(questionSearchQuery);
    return matchesCat && matchesQuery;
  });

  if (countEl) {
    countEl.textContent = `Showing ${filtered.length} of ${INTERVIEW_QUESTIONS.length} Questions`;
  }

  if (filtered.length === 0) {
    container.innerHTML = `
      <div class="card" style="text-align: center; padding: 3rem; color: #64748b;">
        <p style="font-size: 1.1rem; margin-bottom: 0.5rem;">No questions found matching your filter criteria.</p>
        <p style="font-size: 0.9rem;">Try selecting "All" or clearing the search box.</p>
      </div>
    `;
    return;
  }

  container.innerHTML = filtered.map(item => `
    <div class="question-card" id="qcard-${item.id}">
      <div class="question-header" onclick="toggleQuestionAnswer(${item.id})">
        <div class="question-info">
          <span class="question-number">Q${item.id}</span>
          <div>
            <div class="question-title">${escapeHtml(item.question)}</div>
            <div class="question-meta">${escapeHtml(item.category)} · Placement Preparation</div>
          </div>
        </div>
        <div>
          <button class="btn btn-secondary btn-sm" type="button" aria-expanded="false">
            <span class="question-toggle-text" id="toggle-txt-${item.id}">Show Answer</span>
          </button>
        </div>
      </div>
      <div class="answer-tray" id="tray-${item.id}">
        <p><strong>Answer:</strong></p>
        <p style="margin-top: 0.35rem;">${escapeHtml(item.answer)}</p>
      </div>
    </div>
  `).join("");
}

function toggleQuestionAnswer(id) {
  const tray = document.getElementById(`tray-${id}`);
  const toggleTxt = document.getElementById(`toggle-txt-${id}`);
  if (!tray) return;

  const isOpen = tray.classList.contains("open");
  if (isOpen) {
    tray.classList.remove("open");
    if (toggleTxt) toggleTxt.textContent = "Show Answer";
  } else {
    tray.classList.add("open");
    if (toggleTxt) toggleTxt.textContent = "Hide Answer";
  }
}

// =============================================================================
// 7. MCQ MOCK TEST ENGINE (mock-test.html)
// =============================================================================
let testTimerInterval = null;
let testSecondsRemaining = 600; // 10 minutes (600 seconds)
let testAnswers = {};           // map: { questionIndex: selectedOptionIndex }
let currentQuestionIndex = 0;

function setupMockTest() {
  const testRoot = document.getElementById("mock-test-container");
  if (!testRoot) return;

  requireAuth(); // Ensure user is logged in

  // Load existing test progress or start fresh
  const savedState = localStorage.getItem(STORAGE_KEYS.TEST_STATE);
  if (savedState) {
    try {
      const parsed = JSON.parse(savedState);
      testSecondsRemaining = parsed.timeRemaining ?? 600;
      testAnswers = parsed.answers ?? {};
      currentQuestionIndex = parsed.currentQuestionIndex ?? 0;
    } catch (e) {
      testSecondsRemaining = 600;
      testAnswers = {};
      currentQuestionIndex = 0;
    }
  } else {
    testSecondsRemaining = 600;
    testAnswers = {};
    currentQuestionIndex = 0;
  }

  // Start countdown timer
  startTestTimer();

  // Render question palette & current question
  renderQuestionPalette();
  renderCurrentQuestion();

  // Bind controls
  const prevBtn = document.getElementById("btn-prev-q");
  const nextBtn = document.getElementById("btn-next-q");
  const submitBtn = document.getElementById("btn-submit-test");

  if (prevBtn) {
    prevBtn.addEventListener("click", () => {
      if (currentQuestionIndex > 0) {
        currentQuestionIndex--;
        renderCurrentQuestion();
        renderQuestionPalette();
        saveTestProgress();
      }
    });
  }

  if (nextBtn) {
    nextBtn.addEventListener("click", () => {
      if (currentQuestionIndex < MOCK_TEST_QUESTIONS.length - 1) {
        currentQuestionIndex++;
        renderCurrentQuestion();
        renderQuestionPalette();
        saveTestProgress();
      }
    });
  }

  if (submitBtn) {
    submitBtn.addEventListener("click", () => {
      confirmAndSubmitTest();
    });
  }
}

function startTestTimer() {
  if (testTimerInterval) clearInterval(testTimerInterval);

  updateTimerDisplay();

  testTimerInterval = setInterval(() => {
    testSecondsRemaining--;
    updateTimerDisplay();
    saveTestProgress();

    if (testSecondsRemaining <= 0) {
      clearInterval(testTimerInterval);
      alert("Time is up! Your test will now be submitted automatically.");
      finalizeTestSubmission();
    }
  }, 1000);
}

function updateTimerDisplay() {
  const timerEl = document.getElementById("test-timer-display");
  if (!timerEl) return;

  const minutes = Math.floor(testSecondsRemaining / 60);
  const seconds = testSecondsRemaining % 60;
  const formatted = `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;

  timerEl.textContent = formatted;

  if (testSecondsRemaining < 120) {
    timerEl.parentElement.classList.add("warning");
  } else {
    timerEl.parentElement.classList.remove("warning");
  }
}

function saveTestProgress() {
  const state = {
    currentQuestionIndex,
    answers: testAnswers,
    timeRemaining: testSecondsRemaining
  };
  localStorage.setItem(STORAGE_KEYS.TEST_STATE, JSON.stringify(state));
}

function renderCurrentQuestion() {
  const q = MOCK_TEST_QUESTIONS[currentQuestionIndex];
  if (!q) return;

  const questionNumEl = document.getElementById("current-q-num");
  const topicEl = document.getElementById("current-q-topic");
  const promptEl = document.getElementById("current-q-prompt");
  const optionsContainer = document.getElementById("current-q-options");
  const prevBtn = document.getElementById("btn-prev-q");
  const nextBtn = document.getElementById("btn-next-q");

  if (questionNumEl) questionNumEl.textContent = `Question ${currentQuestionIndex + 1} of ${MOCK_TEST_QUESTIONS.length}`;
  if (topicEl) topicEl.textContent = q.topic;
  if (promptEl) promptEl.textContent = q.question;

  if (prevBtn) prevBtn.disabled = currentQuestionIndex === 0;
  if (nextBtn) {
    if (currentQuestionIndex === MOCK_TEST_QUESTIONS.length - 1) {
      nextBtn.style.display = "none";
    } else {
      nextBtn.style.display = "inline-flex";
    }
  }

  // Render 4 options
  if (optionsContainer) {
    const selectedAnswer = testAnswers[currentQuestionIndex];
    optionsContainer.innerHTML = q.options.map((optionText, optIndex) => {
      const isSelected = selectedAnswer === optIndex;
      return `
        <label class="mcq-option-item ${isSelected ? 'selected' : ''}" onclick="selectMockAnswer(${currentQuestionIndex}, ${optIndex})">
          <input type="radio" name="mcq-opt-${currentQuestionIndex}" class="mcq-option-radio" ${isSelected ? 'checked' : ''} value="${optIndex}">
          <span class="mcq-option-text">${escapeHtml(optionText)}</span>
        </label>
      `;
    }).join("");
  }
}

function selectMockAnswer(qIndex, optionIndex) {
  testAnswers[qIndex] = optionIndex;
  renderCurrentQuestion();
  renderQuestionPalette();
  saveTestProgress();
}

function renderQuestionPalette() {
  const paletteContainer = document.getElementById("question-palette-grid");
  const answeredCountEl = document.getElementById("palette-answered-count");
  if (!paletteContainer) return;

  const answeredCount = Object.keys(testAnswers).length;
  if (answeredCountEl) answeredCountEl.textContent = `${answeredCount}/${MOCK_TEST_QUESTIONS.length} Answered`;

  paletteContainer.innerHTML = MOCK_TEST_QUESTIONS.map((_, idx) => {
    const isCurrent = idx === currentQuestionIndex;
    const isAnswered = testAnswers[idx] !== undefined;

    let classes = "palette-btn";
    if (isCurrent) classes += " current";
    if (isAnswered) classes += " answered";

    return `
      <button type="button" class="${classes}" onclick="jumpToQuestion(${idx})">
        ${idx + 1}
      </button>
    `;
  }).join("");
}

function jumpToQuestion(index) {
  currentQuestionIndex = index;
  renderCurrentQuestion();
  renderQuestionPalette();
  saveTestProgress();
}

function confirmAndSubmitTest() {
  const answeredCount = Object.keys(testAnswers).length;
  const unansweredCount = MOCK_TEST_QUESTIONS.length - answeredCount;

  let message = "Are you sure you want to submit your mock test?";
  if (unansweredCount > 0) {
    message = `You have ${unansweredCount} unanswered question(s). Unanswered questions will receive 0 marks. Submit test now?`;
  }

  if (confirm(message)) {
    finalizeTestSubmission();
  }
}

function finalizeTestSubmission() {
  if (testTimerInterval) clearInterval(testTimerInterval);

  // Evaluate Score
  let score = 0;
  MOCK_TEST_QUESTIONS.forEach((q, idx) => {
    const userSelected = testAnswers[idx];
    if (userSelected !== undefined && userSelected === q.correctAnswer) {
      score++;
    }
  });

  const totalQuestions = MOCK_TEST_QUESTIONS.length;
  const percentage = Math.round((score / totalQuestions) * 100);
  const passed = percentage >= 50;

  const secondsTaken = 600 - testSecondsRemaining;
  const minutesTaken = Math.floor(secondsTaken / 60);
  const remSecondsTaken = secondsTaken % 60;
  const durationMinutes = `${minutesTaken} min ${remSecondsTaken} sec`;

  const now = new Date();
  const formattedDate = now.getFullYear() + "-" +
    String(now.getMonth() + 1).padStart(2, "0") + "-" +
    String(now.getDate()).padStart(2, "0") + " " +
    String(now.getHours()).padStart(2, "0") + ":" +
    String(now.getMinutes()).padStart(2, "0");

  const testRecord = {
    id: "TEST-" + Math.floor(1000 + Math.random() * 9000),
    date: formattedDate,
    score,
    totalQuestions,
    percentage,
    passed,
    durationMinutes,
    answers: { ...testAnswers }
  };

  // Save to test history
  const history = JSON.parse(localStorage.getItem(STORAGE_KEYS.HISTORY) || "[]");
  history.push(testRecord);
  localStorage.setItem(STORAGE_KEYS.HISTORY, JSON.stringify(history));

  // Save as last result
  localStorage.setItem(STORAGE_KEYS.LAST_RESULT, JSON.stringify(testRecord));

  // Clear current active test state
  localStorage.removeItem(STORAGE_KEYS.TEST_STATE);

  // Redirect to result page
  window.location.href = "result.html";
}

// =============================================================================
// 8. TEST RESULT & REVIEW MODULE (result.html)
// =============================================================================
function setupResultPage() {
  const resultCard = document.getElementById("result-display-container");
  if (!resultCard) return;

  const raw = localStorage.getItem(STORAGE_KEYS.LAST_RESULT);
  if (!raw) {
    resultCard.innerHTML = `
      <div class="card" style="text-align: center; padding: 3rem;">
        <h3>No recent test result found.</h3>
        <p style="color: #64748b; margin: 1rem 0;">Please take the mock test first to generate your performance report.</p>
        <a href="mock-test.html" class="btn btn-primary">Take Mock Test</a>
      </div>
    `;
    return;
  }

  const result = JSON.parse(raw);

  // Fill Metrics
  const scoreNumEl = document.getElementById("res-score-number");
  const percentageEl = document.getElementById("res-percentage");
  const badgeEl = document.getElementById("res-status-badge");
  const correctCountEl = document.getElementById("res-correct-count");
  const incorrectCountEl = document.getElementById("res-incorrect-count");
  const skippedCountEl = document.getElementById("res-skipped-count");
  const timeTakenEl = document.getElementById("res-time-taken");

  let correctCount = 0;
  let incorrectCount = 0;
  let skippedCount = 0;

  MOCK_TEST_QUESTIONS.forEach((q, idx) => {
    const userAns = result.answers[idx];
    if (userAns === undefined) {
      skippedCount++;
    } else if (userAns === q.correctAnswer) {
      correctCount++;
    } else {
      incorrectCount++;
    }
  });

  if (scoreNumEl) scoreNumEl.textContent = `${result.score} / ${result.totalQuestions}`;
  if (percentageEl) percentageEl.textContent = `${result.percentage}%`;
  if (correctCountEl) correctCountEl.textContent = correctCount;
  if (incorrectCountEl) incorrectCountEl.textContent = incorrectCount;
  if (skippedCountEl) skippedCountEl.textContent = skippedCount;
  if (timeTakenEl) timeTakenEl.textContent = result.durationMinutes || "Under 10 mins";

  if (badgeEl) {
    if (result.passed) {
      badgeEl.className = "score-badge passed";
      badgeEl.textContent = "PASSED - PLACEMENT READY";
    } else {
      badgeEl.className = "score-badge failed";
      badgeEl.textContent = "NEEDS PRACTICE - SCORE UNDER 50%";
    }
  }

  // Render question-by-question review
  const reviewContainer = document.getElementById("result-review-list");
  if (reviewContainer) {
    reviewContainer.innerHTML = MOCK_TEST_QUESTIONS.map((q, idx) => {
      const userChoiceIndex = result.answers[idx];
      const isCorrect = userChoiceIndex === q.correctAnswer;
      const isSkipped = userChoiceIndex === undefined;

      let borderClass = "review-status-correct";
      let statusLabel = `<span style="color: #059669; font-weight: 700;">✓ Correct</span>`;

      if (isSkipped) {
        borderClass = "review-status-skipped";
        statusLabel = `<span style="color: #d97706; font-weight: 700;">⚠ Unanswered (0 Marks)</span>`;
      } else if (!isCorrect) {
        borderClass = "review-status-wrong";
        statusLabel = `<span style="color: #dc2626; font-weight: 700;">✗ Incorrect</span>`;
      }

      return `
        <div class="review-item ${borderClass}">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.5rem;">
            <span style="font-weight: 700; color: #0f172a;">Question ${idx + 1} (${escapeHtml(q.topic)})</span>
            <div>${statusLabel}</div>
          </div>
          <p style="font-weight: 600; color: #1e293b; margin-bottom: 0.75rem;">${escapeHtml(q.question)}</p>

          <div style="margin-bottom: 0.5rem;">
            <div style="font-size: 0.82rem; color: #64748b; font-weight: 600;">Your Selected Answer:</div>
            <div class="review-choice ${isCorrect ? 'review-choice correct-pick' : 'review-choice user-pick'}">
              ${isSkipped ? '<span style="color: #d97706; font-style: italic;">No option selected</span>' : escapeHtml(q.options[userChoiceIndex])}
            </div>
          </div>

          ${!isCorrect ? `
            <div style="margin-bottom: 0.5rem;">
              <div style="font-size: 0.82rem; color: #065f46; font-weight: 600;">Correct Answer:</div>
              <div class="review-choice correct-pick">
                ${escapeHtml(q.options[q.correctAnswer])}
              </div>
            </div>
          ` : ''}

          <div style="font-size: 0.82rem; color: #475569; margin-top: 0.65rem; background: #f8fafc; padding: 0.5rem 0.75rem; border-radius: 4px;">
            <strong>Explanation:</strong> ${escapeHtml(q.explanation)}
          </div>
        </div>
      `;
    }).join("");
  }
}

// =============================================================================
// 9. PREVIOUS RESULTS HISTORY MODULE (results.html)
// =============================================================================
function setupResultsHistoryPage() {
  const tableBody = document.getElementById("history-table-body");
  if (!tableBody) return;

  const history = JSON.parse(localStorage.getItem(STORAGE_KEYS.HISTORY) || "[]");

  if (history.length === 0) {
    tableBody.innerHTML = `
      <tr>
        <td colspan="6" style="text-align: center; color: #64748b; padding: 2.5rem;">
          No test history recorded yet. Complete a mock test to see your performance logs.
        </td>
      </tr>
    `;
    return;
  }

  tableBody.innerHTML = [...history].reverse().map((rec, i) => `
    <tr>
      <td><strong>${rec.id || `#${i + 1}`}</strong></td>
      <td>${escapeHtml(rec.date)}</td>
      <td><strong>${rec.score} / ${rec.totalQuestions}</strong></td>
      <td>
        <span class="score-badge ${rec.passed ? 'passed' : 'failed'}" style="font-size: 0.75rem; padding: 3px 8px;">
          ${rec.percentage}%
        </span>
      </td>
      <td>${escapeHtml(rec.durationMinutes || 'N/A')}</td>
      <td>
        <button class="btn btn-secondary btn-sm" onclick="reviewHistoryTest('${rec.id}')">Review Answers</button>
      </td>
    </tr>
  `).join("");

  const clearBtn = document.getElementById("btn-clear-history");
  if (clearBtn) {
    clearBtn.addEventListener("click", () => {
      if (confirm("Are you sure you want to clear your test history?")) {
        localStorage.setItem(STORAGE_KEYS.HISTORY, JSON.stringify([]));
        setupResultsHistoryPage();
      }
    });
  }
}

// =============================================================================
// 10. STUDENT PROFILE MODULE (profile.html)
// =============================================================================
function setupProfilePage() {
  const form = document.getElementById("profile-form");
  const alertEl = document.getElementById("profile-alert");
  if (!form) return;

  const user = requireAuth();
  if (!user) return;

  // Pre-fill
  document.getElementById("prof-name").value = user.fullName || "";
  document.getElementById("prof-email").value = user.email || "";
  document.getElementById("prof-roll").value = user.rollNo || "";
  document.getElementById("prof-sem").value = user.semester || "Semester 6";
  document.getElementById("prof-role").value = user.targetRole || "Full Stack Developer";

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    if (alertEl) alertEl.innerHTML = "";

    const updatedName = document.getElementById("prof-name").value.trim();
    const updatedRoll = document.getElementById("prof-roll").value.trim();
    const updatedSem = document.getElementById("prof-sem").value;
    const updatedRole = document.getElementById("prof-role").value.trim();
    const newPass = document.getElementById("prof-password").value;

    if (!updatedName) {
      showAlert(alertEl, "Student name cannot be empty.", "error");
      return;
    }

    user.fullName = updatedName;
    user.rollNo = updatedRoll;
    user.semester = updatedSem;
    user.targetRole = updatedRole;
    if (newPass && newPass.length >= 6) {
      user.password = newPass;
    }

    // Save back to active user and all users list
    localStorage.setItem(STORAGE_KEYS.ACTIVE_USER, JSON.stringify(user));

    const users = JSON.parse(localStorage.getItem(STORAGE_KEYS.USERS) || "[]");
    const idx = users.findIndex(u => u.email === user.email);
    if (idx !== -1) {
      users[idx] = user;
      localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
    }

    updateHeaderNav();
    showAlert(alertEl, "Profile details updated successfully!", "success");
  });
}

// =============================================================================
// 11. BASIC ADMIN DASHBOARD (admin.html)
// =============================================================================
function setupAdminPage() {
  const usersCountEl = document.getElementById("admin-users-count");
  if (!usersCountEl) return;

  const users = JSON.parse(localStorage.getItem(STORAGE_KEYS.USERS) || "[]");
  const history = JSON.parse(localStorage.getItem(STORAGE_KEYS.HISTORY) || "[]");

  usersCountEl.textContent = users.length;

  const testsCountEl = document.getElementById("admin-tests-count");
  if (testsCountEl) testsCountEl.textContent = history.length;

  const questionsCountEl = document.getElementById("admin-questions-count");
  if (questionsCountEl) questionsCountEl.textContent = INTERVIEW_QUESTIONS.length;

  // Pass rate
  const passRateEl = document.getElementById("admin-pass-rate");
  if (passRateEl) {
    if (history.length > 0) {
      const passedCount = history.filter(h => h.passed).length;
      passRateEl.textContent = `${Math.round((passedCount / history.length) * 100)}%`;
    } else {
      passRateEl.textContent = "N/A";
    }
  }

  // Render registered users table
  const usersTableBody = document.getElementById("admin-users-table-body");
  if (usersTableBody) {
    usersTableBody.innerHTML = users.map((u, i) => `
      <tr>
        <td>${i + 1}</td>
        <td><strong>${escapeHtml(u.fullName)}</strong></td>
        <td>${escapeHtml(u.email)}</td>
        <td>${escapeHtml(u.rollNo || '21BCE1042')}</td>
        <td>${escapeHtml(u.semester || 'Semester 6')}</td>
      </tr>
    `).join("");
  }

  // Render question manager list
  const qTableBody = document.getElementById("admin-questions-table-body");
  if (qTableBody) {
    qTableBody.innerHTML = INTERVIEW_QUESTIONS.map(q => `
      <tr>
        <td><strong>#${q.id}</strong></td>
        <td><span class="brand-badge">${escapeHtml(q.category)}</span></td>
        <td>${escapeHtml(q.question)}</td>
        <td style="color: #64748b; font-size: 0.8rem;">${escapeHtml(q.answer.substring(0, 75))}...</td>
      </tr>
    `).join("");
  }

  // Reset Demo Factory Data button
  const resetBtn = document.getElementById("btn-reset-demo-data");
  if (resetBtn) {
    resetBtn.addEventListener("click", () => {
      if (confirm("Reset all LocalStorage data to original college demo factory settings?")) {
        localStorage.clear();
        initStorage();
        alert("Demo data reset successfully!");
        window.location.reload();
      }
    });
  }
}

// =============================================================================
// 12. BOOTSTRAP DISPATCHER (DOM Ready)
// =============================================================================
document.addEventListener("DOMContentLoaded", () => {
  initStorage();
  updateHeaderNav();

  setupRegisterForm();
  setupLoginForm();
  setupDashboard();
  setupQuestionsPage();
  setupMockTest();
  setupResultPage();
  setupResultsHistoryPage();
  setupProfilePage();
  setupAdminPage();
});
