# Web Development Interview Preparation System (B.Tech College Project)

A complete, medium-level Web Development Interview Preparation System built with pure HTML5, modern semantic CSS3, and vanilla JavaScript. Designed specifically for B.Tech students to understand, showcase, and explain during college project presentations and viva examinations.

---

### User Review & Critical Decisions

> [!IMPORTANT]
> The following user preferences were confirmed during clarification:
> - **Multi-Page Delivery**: Authentic multi-page static HTML architecture (`index.html`, `login.html`, `register.html`, `dashboard.html`, `questions.html`, `mock-test.html`, `result.html`, `results.html`, `profile.html`, `admin.html`) linked via a shared `css/style.css` stylesheet and `js/app.js` module.
> - **Mock Test Configuration**: 10-minute countdown timer (600 seconds, 1 minute per question) with auto-submit upon timer expiry, real-time question navigation, review indicators, and prevention of unanswered questions being counted as correct.
> - **LocalStorage Data Architecture**: Client-side demo database using browser `localStorage` storing user accounts, active session, mock test question bank, test attempt records, and admin statistics. Clear disclaimer banners specifying frontend demo status.

---

### 1. Overview & Core Concept

- **What It Does**: Provides computer science and engineering students with a self-contained web platform to prepare for frontend, backend, and full-stack technical interviews. Includes 25 categorized core questions with interactive toggleable answers, a timed 10-question MCQ mock examination with instant scoring and detailed answer review, historical performance tracking, profile management, and an administrative metrics dashboard.
- **Target Audience / Persona**: B.Tech / BE Computer Engineering and Information Technology students preparing for campus placements, technical viva voce, and faculty project evaluation.
- **Key Value**: Easy to explain line-by-line during viva examinations, zero build complexity, runs offline or with any standard web browser, and demonstrates fundamental web technologies (HTML DOM, CSS Grid/Flexbox, JavaScript Event Loop & LocalStorage).

---

### 2. User Experience & Visual Design

#### Key User Flows
1. **Discovery & Exploration**: User lands on `index.html` → views project highlights, syllabus coverage (HTML, CSS, JS, PHP, MySQL, Viva), and calls-to-action → navigates to `register.html` or `login.html`.
2. **Authentication Flow**: New student registers account → credentials validated & saved to `localStorage` → redirects to `login.html` → successful login sets active user session → redirects to `dashboard.html`.
3. **Question Repository**: Student opens `questions.html` → filters by topic pills (HTML, CSS, JavaScript, PHP, MySQL, Viva) or uses real-time search → toggles individual "Show/Hide Answer" buttons or expands all answers for study.
4. **Timed Mock Test**: Student launches `mock-test.html` → 10-minute timer begins countdown → student answers 10 randomized MCQs with Previous/Next controls, question palette, and instant status tracking → submits manually or auto-submits on timeout.
5. **Score Evaluation & History**: Test auto-calculates score → student lands on `result.html` displaying score (e.g. 8/10), percentage (80%), grade badge, and question-by-question comparative review (selected answer vs. correct answer with explanation) → result stored in attempt log → viewable under `results.html`.
6. **Profile & Admin Demo**: Student updates name and target placement goals on `profile.html` → explores `admin.html` to inspect demo user count, global test attempts, and question bank management.

#### Visual Identity & Theme
- **Color Palette**: Professional academic dark blue and light blue palette:
  - Dominant Canvas: Crisp clean off-white (`#F8FAFC`) with pure white card surfaces (`#FFFFFF`).
  - Structural Brand: Navy / Deep Slate (`#0F172A`, `#1E293B`) for navigation bar, headings, and footer.
  - Interactive Accents: Royal Blue (`#2563EB`) and Sky Blue (`#0EA5E9`) for action buttons, links, and active states.
  - Status Accents: Forest Emerald (`#059669`) for correct answers/pass grades, Crimson Red (`#DC2626`) for incorrect answers, and Amber (`#D97706`) for unanswered/warning flags.
- **Typography & Hierarchy**:
  - Primary Display & Body: System Neo-Grotesque font stack (`Plus Jakarta Sans`, system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif) for sharp legibility on all devices.
  - Numbers & Timer: Monospace tabular numerals (`font-family: monospace; font-variant-numeric: tabular-nums`) for jitter-free timer countdown and scorecards.
- **Component Styling & Layout**:
  - Clean card borders (`1px solid #E2E8F0`) with subtle elevation shadows (`0 2px 4px rgba(0,0,0,0.04)`).
  - Generous container padding, responsive flex navigation, clear form inputs with active focus states.
  - Anti-slop discipline: No mechanical comment headers, no decorative pulse dots, no fake telemetry tickers, and clean unboxed metadata.

---

### 3. Key Product Decisions & Trade-Offs

- **Multi-Page HTML Architecture vs Single Page**:
  - *Chosen Approach*: Distinct `.html` files linked via relative anchor tags (`<a href="dashboard.html">`) sharing a centralized `css/style.css` and `js/app.js`.
  - *Why*: Perfectly matches B.Tech university curriculum expectations where examiners inspect individual HTML pages, forms, and DOM manipulation scripts. Also runs directly in any local folder without requiring node packages.
- **LocalStorage Data Engine**:
  - *Chosen Approach*: Browser `localStorage` utilizing structured JSON keys (`wd_users`, `wd_active_user`, `wd_test_history`, `wd_questions`, `wd_current_test`).
  - *Why*: Enables genuine persistence across page transitions and browser reloads without complex database installation or backend servers.
- **Viva Preparation Module**:
  - *Chosen Approach*: Includes the exact 25 college questions required by the curriculum, categorized into HTML (4), CSS (4), JavaScript (5), PHP (4), MySQL (4), and Web Development Viva (4), with beginner-friendly explanations.

---

### 4. Technical Architecture & Data Strategy

```
┌────────────────────────────────────────────────────────────────────────┐
│                        WEB BROWSER / CLIENT                            │
├────────────────────────────────────────────────────────────────────────┤
│                                                                        │
│   ┌───────────────┐     ┌───────────────┐     ┌───────────────────┐    │
│   │  index.html   │ ──> │  login.html   │ ──> │  dashboard.html   │    │
│   │ (Hero/Landing)│     │ register.html │     │ (Student Center)  │    │
│   └───────────────┘     └───────────────┘     └─────────┬─────────┘    │
│                                                         │              │
│                 ┌──────────────────────┬────────────────┴───────────┐  │
│                 ▼                      ▼                            ▼  │
│         ┌───────────────┐      ┌───────────────┐            ┌────────┐ │
│         │questions.html │      │mock-test.html │            │profile │ │
│         │ (25 Q&A Hub)  │      │(10-min Timer) │            │admin   │ │
│         └───────────────┘      └───────┬───────┘            └────────┘ │
│                                        ▼                               │
│                                ┌───────────────┐                       │
│                                │  result.html  │                       │
│                                │ results.html  │                       │
│                                └───────────────┘                       │
│                                                                        │
│                                    │                                   │
│                                    ▼                                   │
│   ┌────────────────────────────────────────────────────────────────┐   │
│   │                      Core Engine: js/app.js                    │   │
│   │  • Auth & Session Guard    • Mock Test Engine & Timer          │   │
│   │  • Question Bank & Search  • Score Calculator & History Log    │   │
│   │  • Profile Management      • Admin Stats & Demo Seed Data      │   │
│   └────────────────────────────────┬───────────────────────────────┘   │
│                                    │                                   │
│                                    ▼                                   │
│   ┌────────────────────────────────────────────────────────────────┐   │
│   │                  Client Storage: localStorage                  │   │
│   │  wd_active_user  |  wd_users  |  wd_test_history  |  wd_test   │   │
│   └────────────────────────────────────────────────────────────────┘   │
│                                                                        │
└────────────────────────────────────────────────────────────────────────┘
```

#### File Structure Mapping
- `index.html`: Landing page with project objectives, quick overview, feature cards, syllabus breakdown, and portal access.
- `login.html`: Student login form with input validation, demo helper buttons, and error alerts.
- `register.html`: Student registration form (Full Name, Email, Semester/Year, Password) with instant validation.
- `dashboard.html`: Student dashboard showing greeting, quick stats (Tests taken, Average score, Syllabus progress), quick action links, and recent attempts.
- `questions.html`: The 25 mandatory B.Tech interview questions with category filter chips, search input, and expandable answer trays.
- `mock-test.html`: 10-minute MCQ test interface with real-time countdown, question stepper (1–10), option selection, and clear submit confirmation modal.
- `result.html`: Breakdown of latest completed test with total score, percentage, evaluation verdict, and question review.
- `results.html`: Comprehensive historical test attempts table with date, score, percentage, and review links.
- `profile.html`: Student profile viewer and updater with college roll number, target job role, and account reset.
- `admin.html`: Faculty/Admin demo monitor displaying registered students, test completion count, question counts, and question inspector.
- `css/style.css`: Clean, modular responsive CSS using standard utility variables, responsive grids, and professional college-friendly theme.
- `js/app.js`: Clean vanilla JavaScript with comprehensive comments, modular helper functions, and pre-seeded mock test questions.
